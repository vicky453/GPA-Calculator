# GPA_calc
A simple two tier Application to calculate GPA of a current semester
